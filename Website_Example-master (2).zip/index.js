const express = require('express');
const app = express();
app.use(express.urlencoded({extended: true})) 
const bodyParser= require('body-parser')
app.use(bodyParser.urlencoded({extended: true})) 
var db;

const MongoClient = require('mongodb').MongoClient
app.set('view engine', 'ejs');

MongoClient.connect("mongodb+srv://jeeunkim:kje991229@cluster0.5gtmmnp.mongodb.net/?retryWrites=true&w=majority", function(err, client){
  if (err) return console.log(err)
     db = client.db('login');

    console.log('DB connected')

  app.listen(8080, function() {
    console.log('listening on 8080')
  })
})

app.get('/', function(req, res) { 
  res.sendFile(__dirname +'/login.html')
  })
  app.get('/login', function(req, res) { 
    res.sendFile(__dirname +'/login.html')
    })
app.get('/index', function(req, res) { 
  db.collection('signup').findOne({ email: req.body.email, password: req.body.password }, (err, user)=> {
    if (user={ email: req.body.email, password: req.body.password }) return res.sendFile(__dirname +'/index.html');
      else res.sendFile(__dirname +'/script2.html');
  })
})

app.get('/write', function(req, res) { 
    res.sendFile(__dirname +'/write.html')
  })

  app.get('/web', function(req, res) { 
    res.sendFile(__dirname +'/web.html')
  })

app.get('/list', function(req, res) {
  db.collection('login').find().toArray(function(err, result){
    console.log(result);
    res.render('list.ejs')
  })
})
app.post('/signin', (req, res) => {
   Users.findOne({ id: req.body.id, password: req.body.password }, (err, user) => {
      if (err) return res.status(500).json({ message: '에러!' });
      else if (user) return res.status(200).json({ message: '유저 찾음!', data: user });
      else return res.status(404).json({ message: '유저 없음!' });
   });
});

app.post('/add', function(req, res){
    db.collection('signup').insertOne({email:req.body.email, password: req.body.password}, function(err, result){
      if(err) return console.log("error");
      console.log("save complete...");
      console.log(req.body.email);
      console.log(req.body.password);
    })
    res.sendFile(__dirname +'/script.html')
    
  })