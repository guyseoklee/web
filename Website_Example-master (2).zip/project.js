const express = require('express');
const app = express();
app.use(express.urlencoded({extended: true})) 
const bodyParser= require('body-parser')
app.use(bodyParser.urlencoded({extended: true})) 
var db;

const MongoClient = require('mongodb').MongoClient
app.set('view engine', 'ejs');

MongoClient.connect("mongodb+srv://NaYunHo:620457@cluster0.c1vvofm.mongodb.net/?retryWrites=true&w=majority", function(err, client){
  if (err) return console.log(err)
     db = client.db('login');

    console.log('DB connected')

  app.listen(8080, function() {
    console.log('listening on 8080')
  })
})

app.use('/', express.static("./css"))


app.get('/web', function(req, res) { 
    res.sendFile(__dirname +'/web.html')
  })
// ------------------------------------------------------------
 app.get('/C_tip', function(req, res) { 
    res.sendFile(__dirname +'/CTIP/C_tip.html')
  })
  app.get('/C_tip_write', function(req, res) { 
    res.sendFile(__dirname +'/CTIP/C_tip_write.html')
  })
  app.get('/C_tip_view', function(req, res) { 
    res.sendFile(__dirname +'/CTIP/C_tip_view.html')
  })
  app.get('/C_tip_edit', function(req, res) { 
    res.sendFile(__dirname +'/CTIP/C_tip_edit.html')
  })

  
// ------------------------------------------------------------
 app.get('/C_qna', function(req, res) { 
  res.sendFile(__dirname +'/CQNA/C_qna.html')
})
app.get('/C_qna_write', function(req, res) { 
  res.sendFile(__dirname +'/CQNA/C_qna_write.html')
})
app.get('/C_qna_view', function(req, res) { 
  res.sendFile(__dirname +'/CQNA/C_qna_view.html')
})
app.get('/C_qna_edit', function(req, res) { 
  res.sendFile(__dirname +'/CQNA/C_qna_edit.html')
})

// ------------------------------------------------------------
app.get('/C_study', function(req, res) { 
  res.sendFile(__dirname +'/CSTUDY/C_study.html')
})
app.get('/C_study_write', function(req, res) { 
  res.sendFile(__dirname +'/CSTUDY/C_study_write.html')
})
app.get('/C_study_view', function(req, res) { 
  res.sendFile(__dirname +'/CSTUDY/C_study_view.html')
})
app.get('/C_study_edit', function(req, res) { 
  res.sendFile(__dirname +'/CSTUDY/C_study_edit.html')
})


//---------------------------------------------------------------------------------

// ------------------------------------------------------------
app.get('/E_tip', function(req, res) { 
  res.sendFile(__dirname +'/ETIP/E_tip.html')
})
app.get('/E_tip_write', function(req, res) { 
  res.sendFile(__dirname +'/ETIP/E_tip_write.html')
})
app.get('/E_tip_view', function(req, res) { 
  res.sendFile(__dirname +'/ETIP/E_tip_view.html')
})
app.get('/E_tip_edit', function(req, res) { 
  res.sendFile(__dirname +'/ETIP/E_tip_edit.html')
})


// ------------------------------------------------------------
app.get('/E_qna', function(req, res) { 
res.sendFile(__dirname +'/EQNA/E_qna.html')
})
app.get('/E_qna_write', function(req, res) { 
res.sendFile(__dirname +'/EQNA/E_qna_write.html')
})
app.get('/E_qna_view', function(req, res) { 
res.sendFile(__dirname +'/EQNA/E_qna_view.html')
})
app.get('/E_qna_edit', function(req, res) { 
res.sendFile(__dirname +'/EQNA/E_qna_edit.html')
})

// ------------------------------------------------------------
app.get('/E_study', function(req, res) { 
res.sendFile(__dirname +'/ESTUDY/E_study.html')
})
app.get('/E_study_write', function(req, res) { 
res.sendFile(__dirname +'/ESTUDY/E_study_write.html')
})
app.get('/E_study_view', function(req, res) { 
res.sendFile(__dirname +'/ESTUDY/E_study_view.html')
})
app.get('/E_study_edit', function(req, res) { 
res.sendFile(__dirname +'/ESTUDY/E_study_edit.html')
})


//---------------------------------------------------------------------------------

// ------------------------------------------------------------
app.get('/M_tip', function(req, res) { 
  res.sendFile(__dirname +'/MTIP/M_tip.html')
})
app.get('/M_tip_write', function(req, res) { 
  res.sendFile(__dirname +'/MTIP/M_tip_write.html')
})
app.get('/M_tip_view', function(req, res) { 
  res.sendFile(__dirname +'/MTIP/M_tip_view.html')
})
app.get('/M_tip_edit', function(req, res) { 
  res.sendFile(__dirname +'/MTIP/M_tip_edit.html')
})


// ------------------------------------------------------------
app.get('/M_qna', function(req, res) { 
res.sendFile(__dirname +'/MQNA/M_qna.html')
})
app.get('/M_qna_write', function(req, res) { 
res.sendFile(__dirname +'/MQNA/M_qna_write.html')
})
app.get('/M_qna_view', function(req, res) { 
res.sendFile(__dirname +'/MQNA/M_qna_view.html')
})
app.get('/M_qna_edit', function(req, res) { 
res.sendFile(__dirname +'/MQNA/M_qna_edit.html')
})

// ------------------------------------------------------------
app.get('/M_study', function(req, res) { 
res.sendFile(__dirname +'/MSTUDY/M_study.html')
})
app.get('/M_study_write', function(req, res) { 
res.sendFile(__dirname +'/MSTUDY/M_study_write.html')
})
app.get('/M_study_view', function(req, res) { 
res.sendFile(__dirname +'/MSTUDY/M_study_view.html')
})
app.get('/M_study_edit', function(req, res) { 
res.sendFile(__dirname +'/MSTUDY/M_study_edit.html')
})


//---------------------------------------------------------------------------------

// ------------------------------------------------------------
app.get('/K_tip', function(req, res) { 
  res.sendFile(__dirname +'/KTIP/K_tip.html')
})
app.get('/K_tip_write', function(req, res) { 
  res.sendFile(__dirname +'/KTIP/K_tip_write.html')
})
app.get('/K_tip_view', function(req, res) { 
  res.sendFile(__dirname +'/KTIP/K_tip_view.html')
})
app.get('/K_tip_edit', function(req, res) { 
  res.sendFile(__dirname +'/KTIP/K_tip_edit.html')
})


// ------------------------------------------------------------
app.get('/K_qna', function(req, res) { 
res.sendFile(__dirname +'/KQNA/K_qna.html')
})
app.get('/K_qna_write', function(req, res) { 
res.sendFile(__dirname +'/KQNA/K_qna_write.html')
})
app.get('/K_qna_view', function(req, res) { 
res.sendFile(__dirname +'/KQNA/K_qna_view.html')
})
app.get('/K_qna_edit', function(req, res) { 
res.sendFile(__dirname +'/KQNA/K_qna_edit.html')
})

// ------------------------------------------------------------
app.get('/K_study', function(req, res) { 
res.sendFile(__dirname +'/KSTUDY/K_study.html')
})
app.get('/K_study_write', function(req, res) { 
res.sendFile(__dirname +'/KSTUDY/K_study_write.html')
})
app.get('/K_study_view', function(req, res) { 
res.sendFile(__dirname +'/KSTUDY/K_study_view.html')
})
app.get('/K_study_edit', function(req, res) { 
res.sendFile(__dirname +'/KSTUDY/K_study_edit.html')
})


//---------------------------------------------------------------------------------

// ------------------------------------------------------------
app.get('/EN_tip', function(req, res) { 
  res.sendFile(__dirname +'/EN_TIP/EN_tip.html')
})
app.get('/EN_tip_write', function(req, res) { 
  res.sendFile(__dirname +'/EN_TIP/EN_tip_write.html')
})
app.get('/EN_tip_view', function(req, res) { 
  res.sendFile(__dirname +'/EN_TIP/EN_tip_view.html')
})
app.get('/EN_tip_edit', function(req, res) { 
  res.sendFile(__dirname +'/EN_TIP/EN_tip_edit.html')
})


// ------------------------------------------------------------
app.get('/EN_qna', function(req, res) { 
res.sendFile(__dirname +'/EN_QNA/EN_qna.html')
})
app.get('/EN_qna_write', function(req, res) { 
res.sendFile(__dirname +'/EN_QNA/EN_qna_write.html')
})
app.get('/EN_qna_view', function(req, res) { 
res.sendFile(__dirname +'/EN_QNA/EN_qna_view.html')
})
app.get('/EN_qna_edit', function(req, res) { 
res.sendFile(__dirname +'/EN_QNA/EN_qna_edit.html')
})

// ------------------------------------------------------------
app.get('/EN_study', function(req, res) { 
res.sendFile(__dirname +'/EN_STUDY/EN_study.html')
})
app.get('/EN_study_write', function(req, res) { 
res.sendFile(__dirname +'/EN_STUDY/EN_study_write.html')
})
app.get('/EN_study_view', function(req, res) { 
res.sendFile(__dirname +'/EN_STUDY/EN_study_view.html')
})
app.get('/EN_study_edit', function(req, res) { 
res.sendFile(__dirname +'/ENSTUDY/EN_study_edit.html')
})


//---------------------------------------------------------------------------------

// ------------------------------------------------------------
app.get('/S_tip', function(req, res) { 
  res.sendFile(__dirname +'/STIP/S_tip.html')
})
app.get('/S_tip_write', function(req, res) { 
  res.sendFile(__dirname +'/STIP/S_tip_write.html')
})
app.get('/S_tip_view', function(req, res) { 
  res.sendFile(__dirname +'/STIP/S_tip_view.html')
})
app.get('/S_tip_edit', function(req, res) { 
  res.sendFile(__dirname +'/STIP/S_tip_edit.html')
})


// ------------------------------------------------------------
app.get('/S_qna', function(req, res) { 
res.sendFile(__dirname +'/SQNA/S_qna.html')
})
app.get('/S_qna_write', function(req, res) { 
res.sendFile(__dirname +'/SQNA/S_qna_write.html')
})
app.get('/S_qna_view', function(req, res) { 
res.sendFile(__dirname +'/SQNA/S_qna_view.html')
})
app.get('/S_qna_edit', function(req, res) { 
res.sendFile(__dirname +'/SQNA/S_qna_edit.html')
})

// ------------------------------------------------------------
app.get('/S_study', function(req, res) { 
res.sendFile(__dirname +'/SSTUDY/S_study.html')
})
app.get('/S_study_write', function(req, res) { 
res.sendFile(__dirname +'/SSTUDY/S_study_write.html')
})
app.get('/S_study_view', function(req, res) { 
res.sendFile(__dirname +'/SSTUDY/S_study_view.html')
})
app.get('/S_study_edit', function(req, res) { 
res.sendFile(__dirname +'/SSTUDY/S_study_edit.html')
})


//---------------------------------------------------------------------------------

// ------------------------------------------------------------
app.get('/ETC_tip', function(req, res) { 
  res.sendFile(__dirname +'/CTIP/C_tip.html')
})
app.get('/ETC_tip_write', function(req, res) { 
  res.sendFile(__dirname +'/CTIP/C_tip_write.html')
})
app.get('/ETC_tip_view', function(req, res) { 
  res.sendFile(__dirname +'/CTIP/C_tip_view.html')
})
app.get('/ETC_tip_edit', function(req, res) { 
  res.sendFile(__dirname +'/CTIP/C_tip_edit.html')
})


// ------------------------------------------------------------
app.get('/ETC_qna', function(req, res) { 
res.sendFile(__dirname +'/ETCQNA/ETC_qna.html')
})
app.get('/ETC_qna_write', function(req, res) { 
res.sendFile(__dirname +'/ETCQNA/ETC_qna_write.html')
})
app.get('/ETC_qna_view', function(req, res) { 
res.sendFile(__dirname +'/ETCQNA/ETC_qna_view.html')
})
app.get('/ETC_qna_edit', function(req, res) { 
res.sendFile(__dirname +'/ETCQNA/ETC_qna_edit.html')
})

// ------------------------------------------------------------
app.get('/ETC_study', function(req, res) { 
res.sendFile(__dirname +'/ETCSTUDY/ETC_study.html')
})
app.get('/ETC_study_write', function(req, res) { 
res.sendFile(__dirname +'/ETCSTUDY/ETC_study_write.html')
})
app.get('/ETC_study_view', function(req, res) { 
res.sendFile(__dirname +'/ETCSTUDY/ETC_study_view.html')
})
app.get('/ETC_study_edit', function(req, res) { 
res.sendFile(__dirname +'/ETCSTUDY/ETC_study_edit.html')
})


//---------------------------------------------------------------------------------
app.get('/notice', function(req, res) { 
  res.sendFile(__dirname +'/notice.html')
  })
  app.get('/script', function(req, res) { 
    res.sendFile(__dirname +'/script.html')
    })
    app.get('/script2', function(req, res) { 
      res.sendFile(__dirname +'/script2.html')
      })
  app.get('/login', function(req, res) { 
    res.sendFile(__dirname +'/login.html')
    })

  app.get('/write', function(req, res) { 
    res.sendFile(__dirname +'/write.html')
    })
  app.get('/log_suc', function(req, res) { 
     res.sendFile(__dirname +'/log_suc.html')
    })
    app.post('/signin',function(req,res){
      db.collection('signup').findOne({email:req.body.email, password: req.body.password}, function(err, result){
          if(err) return console.log("error");
          if(!result) { 
            return  res.sendFile(__dirname +'/script2.html')
          }
          if(result) {
            
            res.sendFile(__dirname +'/web.html')
          }
        })
    })
    app.get('/post_reply_view', function(req, res) { 
      db.collection('text').find().toArray(function(err, result){
      console.log(result);
      res.render('post_reply_view.ejs', {loginfo : result})
    })
     })
    app.post('/add', function(req, res){
      db.collection('text').insertOne({id:req.body.id, text: req.body.text}, function(err, result){
        if(err) return console.log("error");
        console.log("save complete...");
        console.log(req.body.id);
        console.log(req.body.text);
      })
      res.sendFile(__dirname +'/script3.html')
      })
      app.post('/add2', function(req, res){
        db.collection('signup').insertOne({email:req.body.email, password: req.body.password, sex: req.body.sex
        ,nickname: req.body.nickname , year: req.body.year , month: req.body.month , day: req.body.day}, function(err, result){
          if(err) return console.log("error");
          console.log("save complete...");
          console.log(req.body.email);
          console.log(req.body.password);
          console.log(req.body.sex);
          console.log(req.body.nickname);
          console.log(req.body.year);
          console.log(req.body.month);
          console.log(req.body.day);
        })
        res.sendFile(__dirname +'/script.html')
        
      })    




